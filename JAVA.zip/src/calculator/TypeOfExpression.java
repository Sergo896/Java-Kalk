package calculator;

public enum TypeOfExpression {
    /** Типы выражений: арабские либо римские */
    ARABIC,
    ROMAN
}
